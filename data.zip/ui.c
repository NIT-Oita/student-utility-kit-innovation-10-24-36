#include<stdio.h>

void midasi( char str[] ){
    printf("\n\n================================\n======%s======\n================================\n\n", str);
}
void kaigyo( int kaisu ){
    for(int i = 0; i < kaisu; i++){
        printf("\n");
    }
}
